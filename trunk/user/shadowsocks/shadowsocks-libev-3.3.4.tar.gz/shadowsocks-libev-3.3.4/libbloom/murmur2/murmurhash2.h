
#ifndef _BLOOM_MURMURHASH2
#define _BLOOM_MURMURHASH2

unsigned int murmurhash2(const void * key, int len, const unsigned int seed);

#endif
