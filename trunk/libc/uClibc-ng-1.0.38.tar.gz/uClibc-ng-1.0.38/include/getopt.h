/* This file will not be installed if not using getopt_long. */

#include <bits/getopt.h>

